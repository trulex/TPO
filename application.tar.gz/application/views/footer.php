<!--avtor:darko-->
<?php $url=base_url(); ?>
<div id="footer">
TPO skupina 16<?php if (isset($rights)) {echo ' | <a href="'.$url.'index.php/home/logout" style="color:black">Logout</a>'; }?>
</div>
</body>
</html>