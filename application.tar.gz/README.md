Preden pushaš, preveri trenutno verzijo in jo posodobi z novo kodo, da je ne bi povozil. Ne pozabi še osvežiti baze na strežniku.
V podatkovni bazi, če ne moreš nobenega stolpca uporabit kot primary key poj uporabi "id"
Za tuje ključe naj bodo oznake jasne in enake kot v drugih tabelah (TID(Tasks.id), UID(Users.id),SpID(Sprints.id),StID(Sprints.id)...)

A pa še to vsak naj nardi svoj branch pa bomo poj mergal.